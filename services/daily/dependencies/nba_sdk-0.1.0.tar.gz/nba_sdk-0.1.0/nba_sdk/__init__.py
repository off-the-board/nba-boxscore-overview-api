BASE_URL = "https://stats.nba.com/stats"
